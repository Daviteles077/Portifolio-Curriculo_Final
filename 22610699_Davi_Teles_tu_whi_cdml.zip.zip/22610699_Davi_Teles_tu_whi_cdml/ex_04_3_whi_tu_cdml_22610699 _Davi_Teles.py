soma = 0
N = 4  

for i in range(1, N+1):
    nota = float(input(f"Digite a nota do aluno número {i}: "))
    soma += nota

media = soma / N
print(f"Média da turma = {media:.2f}")
 