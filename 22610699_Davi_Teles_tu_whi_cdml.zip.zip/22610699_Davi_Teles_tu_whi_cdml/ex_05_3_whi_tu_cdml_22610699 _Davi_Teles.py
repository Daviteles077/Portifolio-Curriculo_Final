soma = 0
contador = 0

while True:
    numero = int(input("Digite um número (-1 para sair): "))
    if numero == -1:
        break
    soma += numero
    contador += 1

print(f"Quantidade de números: {contador}")
print(f"Soma dos valores: {soma}")
