n = int(input("Digite um número inteiro: "))
print(f"Tabuada do {n}")

for i in range(11):
    print(f"{n} x {i} = {n*i}")
