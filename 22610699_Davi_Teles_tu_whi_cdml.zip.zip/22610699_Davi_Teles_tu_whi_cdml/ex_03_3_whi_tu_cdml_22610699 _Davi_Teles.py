print("CONVERSAO FAHREINHEIT – CELSIUS")
print("CELSIUS        FAHREINHEIT")

inicio = int(input("Digite o valor inicial em Fahrenheit: "))
fim = int(input("Digite o valor final em Fahrenheit: "))

f = inicio
while f <= fim:
    c = (5/9) * (f - 32)
    print(f"{c:8.2f}        {f:8.2f}")
    f += 1
