N = int(input('Digite a quantidade de números '))

soma = 0 
contador = 0

while contador < N:
    numero =  float(input(f'Digite o {contador+1} número: '))
    soma += numero 
    contador += 1 

    media = soma / N 

    print(f'A media dos {N} números é: {media:.2f}')
