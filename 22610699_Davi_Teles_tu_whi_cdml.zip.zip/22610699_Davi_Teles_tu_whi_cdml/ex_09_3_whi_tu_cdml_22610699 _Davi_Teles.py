n = int(input("Digite um número inteiro maior que 1: "))

i = 1
while i <= n:
    print(i)
    i += 1
