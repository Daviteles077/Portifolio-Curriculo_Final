print("CONVERSAO FAHREINHEIT – CELSIUS")
print("CELSIUS        FAHREINHEIT")

f = 32
contador = 0

while contador < 20:
    c = (5/9) * (f - 32)
    print(f"{c:8.2f}        {f:8.2f}")
    f += 1
    contador += 1




